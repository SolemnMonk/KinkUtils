package monk.solemn.kutils.data.spring.component;

import monk.solemn.kutils.data.dao.CredentialDao;

public interface CredentialDaoService {
	public CredentialDao getCredentialDao();
}
