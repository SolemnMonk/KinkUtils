package monk.solemn.kutils.data.spring.component;

import monk.solemn.kutils.data.dao.ShootDao;

public interface ShootDaoService {
	public ShootDao getShootDao();
}
