package monk.solemn.kutils.data.spring.component;

import monk.solemn.kutils.data.dao.ActorDao;

public interface ActorDaoService {
	public ActorDao getActorDao();
}
