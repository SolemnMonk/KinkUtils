package monk.solemn.kutils.data.spring.component;

import monk.solemn.kutils.data.dao.ConfigDao;

public interface ConfigDaoService {
	public ConfigDao getConfigDao();
}
