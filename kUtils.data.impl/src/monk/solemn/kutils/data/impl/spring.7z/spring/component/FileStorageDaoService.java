package monk.solemn.kutils.data.spring.component;

import monk.solemn.kutils.data.dao.FileStorageDao;

public interface FileStorageDaoService {
	public FileStorageDao getFileStorageDao();
}
