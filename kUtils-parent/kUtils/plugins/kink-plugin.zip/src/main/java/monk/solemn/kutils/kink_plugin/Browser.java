package monk.solemn.kutils.kink_plugin;

import org.openqa.selenium.WebDriver;

import monk.solemn.kutils.api.shoots.SeleniumShootBrowser;

public class Browser implements SeleniumShootBrowser {
	@Override
	public void loadBrowsePage(WebDriver driver) {
	}

	@Override
	public void previousBrowsePage(WebDriver driver) {
	}

	@Override
	public void nextBrowsePage(WebDriver driver) {
	}

	@Override
	public void loadShoot(WebDriver driver) {
	}
}
